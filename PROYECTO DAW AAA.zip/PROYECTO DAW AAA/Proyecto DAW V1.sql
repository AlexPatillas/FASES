CREATE TABLE direcciones (
  id NUMBER,
  provincia VARCHAR(20),
  ciudad VARCHAR(20),  
  calle VARCHAR2(30)  NOT NULL,
  numero NUMBER(3)  NOT NULL,
  piso NUMBER(30),
  mano VARCHAR2(3),
  codigo_postal NUMBER(5),
  CONSTRAINT dir_id_pk PRIMARY KEY (id)
);

CREATE TABLE kilometros (
  id NUMBER,
  km_inicio NUMBER(5,3),
  km_final NUMBER(5,3),
  CONSTRAINT km_id_pk PRIMARY KEY (id)
);

CREATE TABLE gastos (
  id NUMBER, 
  gasoil NUMBER(3,2),
  peaje NUMBER(2,2),
  dietas NUMBER(3,2),
  otros NUMBER(5,2),
  CONSTRAINT gas_id_pk PRIMARY KEY (id)
);

CREATE TABLE Centro ( 
  Codigo NUMBER(2),
  Nombre VARCHAR2 (20) NOT NULL,
  Direccion NUMBER NOT NULL,
  Telefono NUMBER (9) NOT NULL,
  CONSTRAINT cen_cod_pk PRIMARY KEY (Codigo),
  CONSTRAINT cen_dir_fk FOREIGN KEY (Direccion) REFERENCES Direcciones(id)
);

CREATE TABLE Trabajador (
  DNI VARCHAR2 (9),
  Nombre VARCHAR2 (20) NOT NULL,
  Apellido1 VARCHAR2 (30) NOT NULL,
  Apellido2 VARCHAR2 (30) NOT NULL,
  Direccion NUMBER NOT NULL,
  Tel_Emp NUMBER (9) NOT NULL,
  Tel_Per NUMBER (9),
  Salario NUMBER (5,2),
  Fecha_Nac DATE,
  tipo VARCHAR2(10),
  Centro NUMBER (2) NOT NULL,
  CONSTRAINT tra_dni_pk PRIMARY KEY (DNI),
  CONSTRAINT tra_cen_fk FOREIGN KEY (Centro) REFERENCES Centro(Codigo),
  CONSTRAINT tra_dir_fk FOREIGN KEY (Direccion) REFERENCES Direcciones(id),
  CONSTRAINT tra_tipo_ck CHECK (lower(tipo) in ('logistica','administracion'))
);

CREATE TABLE Login (
  DNI VARCHAR2(9),
  usuario VARCHAR2(20) NOT NULL,
  contrase�a VARCHAR2(20) NOT NULL,
  CONSTRAINT logn_dni_pk PRIMARY KEY (DNI),
  CONSTRAINT logn_dni_fk FOREIGN KEY (DNI) REFERENCES Trabajador(DNI)  
);

CREATE TABLE aviso (
  id NUMBER,
  descripcion VARCHAR2(200),
  DNI VARCHAR2(9),
  CONSTRAINT avi_id_pk PRIMARY KEY (id),
  CONSTRAINT avi_dni_fk FOREIGN KEY (DNI) REFERENCES Trabajador(DNI)
);

CREATE TABLE Vehiculo (
  Matricula VARCHAR2(10),
  Marca VARCHAR2(20),
  Modelo VARCHAR2(20),
  Peso NUMBER(5,3) NOT NULL,
  CONSTRAINT veh_mat_pk PRIMARY KEY (Matricula)
);

CREATE TABLE Parte (
  Albaran NUMBER,
  Matricula VARCHAR2(10) NOT NULL,
  DNI VARCHAR2 (9) NOT NULL,
  Kilometros NUMBER NOT NULL,
  Validacion VARCHAR2(2) NOT NULL,
  Gastos NUMBER,
  Incidencias VARCHAR2(300),
  CONSTRAINT par_alb_pk PRIMARY KEY (Albaran),
  CONSTRAINT par_dni_fk FOREIGN KEY (DNI) REFERENCES Trabajador(DNI),
  CONSTRAINT par_mat_fk FOREIGN KEY (Matricula) REFERENCES Vehiculo,
  CONSTRAINT par_val_ck CHECK (lower(Validacion) IN ('si','no')),
  CONSTRAINT par_gas_fk FOREIGN KEY (Gastos) REFERENCES Gastos(id),
  CONSTRAINT par_km_fk FOREIGN KEY (Kilometros) REFERENCES Kilometros(id)
);

CREATE TABLE viaje (
  id NUMBER,
  hora_ini NUMBER(2,2) NOT NULL,
  hora_fin NUMBER(2,2) NOT NULL,
  albaran NUMBER,
  CONSTRAINT via_id_pk PRIMARY KEY (id),
  CONSTRAINT via_alb_fk FOREIGN KEY (albaran) REFERENCES parte
);